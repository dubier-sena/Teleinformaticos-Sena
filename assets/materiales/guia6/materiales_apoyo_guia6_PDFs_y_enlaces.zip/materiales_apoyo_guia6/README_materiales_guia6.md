# Materiales de apoyo – Guía 6 (Planificar la información)

Este paquete incluye **material PDF** útil para apoyar las actividades de la guía (diagnóstico, seguridad de la información, copias de seguridad e incidentes).

## 1) PDFs incluidos en este paquete

1. **INCIBE – Guía de ciberseguridad para todos** (PDF)
2. **Protección de la información (INCIBE) – copia espejo** (PDF)
3. **Copias de seguridad, borrado seguro y tipos de almacenamiento (12 consejos)** (PDF)
4. **MinTIC – Política General de Seguridad Digital en Colombia (2015)** (PDF)
5. **MinTIC (Gobierno Digital) – Guía para la Gestión y Clasificación de Incidentes** (PDF)
6. **MinEducación – Guía de implementación de la política de seguridad digital** (PDF)

> Nota: los títulos se ajustaron para que sean fáciles de identificar al descargar.

## 2) Enlaces oficiales para descargar software (no incluidos)

Por seguridad, este paquete **no incluye instaladores (.exe) ni archivos .zip con ejecutables**.
En el archivo **Enlaces_descarga_software.txt** están los enlaces oficiales recomendados para:
- LibreOffice
- 7-Zip
- CPU-Z
- CrystalDiskInfo
- CmapTools (mapas conceptuales)
- Alternativas web: Canva / MindMeister

## 3) Sugerencia de uso según actividades

- **Mapa conceptual (3.2.2):** CmapTools / Canva / MindMeister.
- **Diagnóstico e inventario (3.3.x):** CPU-Z, CrystalDiskInfo, (opcional) Belarc Advisor.
- **Seguridad y respaldo (3.4):** usa los PDFs de copias de seguridad y los documentos de MinTIC.

